package rt.discovery.yash;





public class Sentiments {
	
	 public static String  POSITIVE = "Positive"; 
	 public static String NEGATIVE = "Negative";
	 public static String NEUTRAL = "Neutral";
	 public static String CONFUSED = "Confused";
	 
	 String id_filed = "id_str";
	 
	 

}
